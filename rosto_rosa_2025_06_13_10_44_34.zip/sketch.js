function setup() {
  createCanvas(400, 400);
}
let olhoX;
let olhoY;

function draw() {
background("rgb(221,149,221)");
  fill("rgb(248,199,208)");
circle(200,200,300); // rosto
  fill("white");
circle(150,150,60);  // olho esquerdo
circle(250,150,60)   // olho direito
  fill('rgb(241,148,164)')
  ellipse(200,270,80,40);
  line(160,270,235,270);
  fill('pink');
triangle(200,180,170,220,220,220);  // nariz
  fill("#805F53")
  arc(160,116,80,20,3,20,6,20,CHORD)
  arc(260,116,80,20,,20,6,20,CHORD)
//circle(150,150,10);
  fill('#795548');
 // circle(250,150,10);   //pupila direita
 
  olhoX = map(mouseX, 0,400,130,166);  //nova pupila esquerda
olhoY = map(mouseY, 0,400,130,169);  //nova pupila direita

  circle(olhoX,olhoY,10);
circle(olhoX+100,olhoY,10);
  if(mouseIsPressed){
console.log(mouseX,mouseY);
}
}

